# Student-CMS
this is the student management system for a college
